from .client import SuperClient

app = SuperClient()
