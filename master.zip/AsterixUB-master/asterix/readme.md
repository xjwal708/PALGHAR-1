>This directory contains all the necessary files which are needed to run the bot, deleting or altering any of the file will might give error.

>You can make changes here only if and only if you have basic knowledge about programming.

