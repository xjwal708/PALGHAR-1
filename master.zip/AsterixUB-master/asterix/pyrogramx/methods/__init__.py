from .decorators import Decorators


class Methods(Decorators):
    pass
