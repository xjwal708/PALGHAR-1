from .rawfunctions import RawFunctions
from .utilities import Utilities


class Functions(RawFunctions, Utilities):
    pass
