from .alertuser import AlertUser


class Decorators(AlertUser):
    pass
