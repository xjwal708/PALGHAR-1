class Variables(object):
    # lower
    message_ids = {}

    # assistant
    assistant_name = "Kushina"
    assistant_age = "18"
    assistant_gender = "Female"

    # userbot
    userbot_name = "Asterix"

    # photo
    PIC = "https://telegra.ph/file/38eec8a079706b8c19eae.mp4"
