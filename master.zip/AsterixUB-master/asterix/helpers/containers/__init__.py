from .strings import Strings
from .variables import Variables


class Containers(Strings, Variables):
    pass
